
"""
Pixel Counter by Amin Aria
"""
import cv2
import numpy as np



TXT='pixelcount'
f = open(TXT+'.txt', 'w')
f.write('Image Name;Pixel Count'+'\n')


import pandas as pd
df = pd.read_excel('exp 13/Images_list.xlsx') # can also index sheet by name or fetch all sheets
predlist = df['prediction'].tolist()


for address in predlist:
    img = cv2.imread(address)
    shape = img.shape

    area=[]
    
    for i in range(shape[0]):
        a=np.asarray(np.nonzero(img[i,:,0]))
        ashape=a.shape
        sd=np.std(a)
        if ashape[1]>20  and  sd < shape[1]/10 :
            area.append(np.median(a))
    
    area=np.asarray(area)
    area.shape[0]
    
    l=0#length
    for j in range(1,area.shape[0]):
        l=l+np.sqrt(1+min(0.5,area[j]-area[j-1])**2)
    
    l
        
    f.write('{};{} \n'.format(address,l))
        #np.savetxt("edge.csv", edge, delimiter=",")    


f.close()  
   
    
    
    
    
    
    
'''    
#test block for old method    
    margin=int(img.shape[1]/3) #Look at the middle third of an image to find a crack
    img=img[:,margin:2*margin,:]
    shape = img.shape
    
    l=0
    edge=[]
    for i in range(shape[0]):
        a=np.nonzero(img[i,:,0])
        if img[i,a,0].shape[1] !=0 :
            notch=np.amax(a)-np.amin(a)
            width=img[i,a,0].shape[1]
        else:
            notch=0
            width=0
    
           
        if  (0 < notch < shape[1]/2) or (shape[1]/4 < width <shape[1]/2) :
            edge.append(np.median(np.nonzero(img[i,:,0])))
        else:
            edge.append(0)
            
        
        if i > 49 and sum(edge[(i-50):i])> 0 :
            if i % 50 ==0 :
                if abs(np.median(edge[(i-5):(i+5)])-np.median(edge[(i-55):(i-45)])) < 50 :
                     l=l+np.sqrt(50**2+(np.median(edge[(i-5):(i+5)])-np.median(edge[(i-55):(i-45)]))**2)
                else:
                    l=l+50
                print(l)
    f.write('{};{} \n'.format(address,l))
    #np.savetxt("edge.csv", edge, delimiter=",")    


f.close()  

'''


'''
#test block for new method
img = cv2.imread('exp 13/0823025319_pred.png')
#margin=int(img.shape[1]/3) #Look at the middle third of an image to find a crack
#img=img[:,margin:2*margin,:]
shape = img.shape


area=[]
for i in range(shape[0]):
    a=np.asarray(np.nonzero(img[i,:,0]))
    ashape=a.shape
    sd=np.std(a)
    if ashape[1]>20  and  sd < shape[1]/10 :
        area.append(np.median(a))

area=np.asarray(area)
area.shape[0]

l=0#length
for j in range(1,area.shape[0]):
    l=l+np.sqrt(1+min(0.5,area[j]-area[j-1])**2)

l
    



#counts = np.bincount(area)
#mode= np.argmax(counts)
area=np.asarray(area)
area= area[area<150]
length=sum(area[20<area])/np.median(area[20<area])

length

'''





























